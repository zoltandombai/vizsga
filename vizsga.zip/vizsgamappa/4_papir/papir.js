function getCalc(params) {
    let szelesseg = document.getElementById("szelesseg").value
    let magassag = document.getElementById("magassag").value
    terulet = (szelesseg * magassag) / 1000;
    document.getElementById("terulet").innerHTML = terulet;

    let papir = 32;
    terulet = Math.round((szelesseg + magassag) / 1000);
    koltseg = terulet * papir;
    document.getElementById("koltseg").innerHTML = koltseg;
    koltseg = Number;
}

if (szelesseg, magassag < 50) {
alert("Ellenőrízze az adatokat!")
}